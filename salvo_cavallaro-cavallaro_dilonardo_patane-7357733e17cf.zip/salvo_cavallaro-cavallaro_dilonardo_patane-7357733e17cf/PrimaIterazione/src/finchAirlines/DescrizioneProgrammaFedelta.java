package finchAirlines;

public class DescrizioneProgrammaFedelta {
	
	private double coefficientePunti;

	public double getCoefficientePunti() {
		return coefficientePunti;
	}

	public void setCoefficientePunti(double coefficientePunti) {
		this.coefficientePunti = coefficientePunti;
	}

	public DescrizioneProgrammaFedelta(double coefficientePunti) {
		this.coefficientePunti = coefficientePunti;
	}
	
	

}
