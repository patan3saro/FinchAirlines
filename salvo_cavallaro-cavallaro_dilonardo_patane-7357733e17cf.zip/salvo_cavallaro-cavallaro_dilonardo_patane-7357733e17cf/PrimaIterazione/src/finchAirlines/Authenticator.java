package finchAirlines;

public interface Authenticator {
	public boolean verificaPassword(String password);
}
