package finchAirlines;

public class CartaDiCredito {
	private String numero;
	
	public CartaDiCredito(String numero) {
		this.numero = numero;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

}
